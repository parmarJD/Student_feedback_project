<?php
// Include the database connection file
include '../DB connection/DB_connection.php'; // Make sure this path is correct

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start(); 
    // Get form data and sanitize it
    $name = htmlspecialchars(trim($_POST['Name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $courseList = htmlspecialchars(trim($_POST['courseList']));
    $semesterList = htmlspecialchars(trim($_POST['semesterList']));
    $password = htmlspecialchars(trim($_POST['password']));
    $submittedCaptcha = htmlspecialchars(trim($_POST['captchaInput']));
    $storedCaptcha = htmlspecialchars(trim($_POST['validateCaptcha']));

    if ($submittedCaptcha === $storedCaptcha) {
        echo "CAPTCHA validated successfully.";
        // Process the form data here
    } else {
        echo "CAPTCHA validation failed. Please try again.";
        return false;
    }
    // Prepare an SQL statement to insert data
    $sql = "INSERT INTO student (NAME,EMAIL,COURSE_NAME,SEMESTER,PASSWORD) VALUES (?,?,?,?,?)";

    // Initialize a prepared statement
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param("sssss", $name,$email,$courseList,$semesterList,$password);

    if ($stmt->execute()) {
        // Close the statement and connection
        $stmt->close();
        $conn->close();
        
        $_SESSION['message'] = "Registration successful! You can now log in.";
        // Redirect to login.php
        header("Location: login.php");
        exit(); 
    } else {
        // Close the statement and connection
        $stmt->close();
        $conn->close();
        
        // Display error message
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
