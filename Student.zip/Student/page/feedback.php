<?php
include '../DB connection/DB_connection.php'; 
    session_start();
    $id = 1; 
    $user_email = $_SESSION['user_email']; 

    $sql = "SELECT NAME, EMAIL, COURSE_NAME,SEMESTER FROM student WHERE EMAIL = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user_email); 
    $stmt->execute();
    $result = $stmt->get_result();
    $date = date('Y-m-d');

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = htmlspecialchars($row['NAME']);
        $courseList = htmlspecialchars($row['COURSE_NAME']);
        $semesterList = htmlspecialchars($row['SEMESTER']);
    } else {
        $name = '';
        $courseList = '';
        $semesterList = '';
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = htmlspecialchars(trim($_POST['Name']));
        $Course = htmlspecialchars(trim($_POST['Course']));
        $Semester = htmlspecialchars(trim($_POST['Semester']));
        $Course = htmlspecialchars(trim($_POST['Course']));
        $feedback = htmlspecialchars(trim($_POST['feedback']));
        
        if (isset($_POST['options'])) {
            $options = $_POST['options']; // Array of selected values
            $options_str = implode(',', $options); // Convert array to comma-separated string
        } else {
            $options_str = ''; // No options selected
        }
    
        $stmt = $conn->prepare("INSERT INTO feedback (Stud_name,email,Course,Semester,Tags,feedback) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssssss", $name,$user_email,$Course,$Semester,$options_str,$feedback); 
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "feedback submitted successfully.";
        } else {
            echo "Error in data saving.";
        }

       
    }
    
    $stmt->close();
    $conn->close();    
?>



<html>
<head>  
    <title>Feedback Form</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Feedback Form</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="Name">Name:</label>
                <input type="text" id="Name" name="Name" value="<?php echo $name; ?>" required>
            </div>
            <div class="form-group">
                <label for="date">DATE:</label>
                <input type="date" id="date" name="date" value="<?php echo $date; ?>" required>
            </div>
            <div class="form-group">
                <label for="Course">Course:</label>
                <input type="text" id="Course" name="Course" value="<?php echo $courseList; ?>" required>
            </div>
            <div class="form-group">
                <label for="Semester">Semester:</label>
                <input type="text" id="Semester" name="Semester" value="<?php echo $semesterList; ?>" required>
            </div>
            
            <div class="form-group checkbox-group">
                <div class="checkbox-item">
                    <label for="optionA">poor</label>
                    <input type="checkbox" id="poor" name="options[]" value="poor">
                </div>
                <div class="checkbox-item">
                    <label for="optionB">medium</label>
                    <input type="checkbox" id="medium" name="options[]" value="medium">
                </div>
                <div class="checkbox-item">
                    <label for="optionC">good</label>
                    <input type="checkbox" id="good" name="options[]" value="good">
                </div>
                <div class="checkbox-item">
                    <label for="optionD">excelance</label>
                    <input type="checkbox" id="excelance" name="options[]" value="excelance">
                </div>
            </div>

            <div class="form-group">
                <label for="Feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" rows="4" cols="38" required></textarea>
            </div>
            <div class="form-group">
                <button type="submit" name="submit">Submit Feedback</button>
            </div>
        </form>
    </div>
</body>
</html>
