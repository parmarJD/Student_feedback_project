<?php
include '../DB connection/DB_connection.php'; 
session_start(); // Start the session
$errorMessage = '';       

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['error']);
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $EMAIL = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $submittedCaptcha = htmlspecialchars(trim($_POST['captchaInput']));
    $storedCaptcha = htmlspecialchars(trim($_POST['validateCaptcha']));

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    if ($submittedCaptcha !== $storedCaptcha) {
        $errorMessage = 'CAPTCHA validation failed. Please try again.';       
    }
    else{

    $stmt = $conn->prepare("SELECT PASSWORD FROM student WHERE EMAIL = ?");
    $stmt->bind_param("s", $EMAIL);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($hashedPassword);
        $stmt->fetch();

        // Verify the provided password against the hashed password
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['user_email'] = $EMAIL;
            header('Location: feedback.php');
            exit();
        } else {
            $_SESSION['error'] = "invalid password";
            header('Location: login.php');
        }
    } else {
        $_SESSION['error'] = "User not found.";
        header('Location: login.php');

    }
   
    $stmt->close();
    $conn->close();
    }
}
?>

<html>
<head>  
    <title>Login Form</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php if ($message): ?>
        <div id="toast" class="toast"><?php echo $message; ?></div>
    <?php endif; ?>
    <div class="form-container">
        <h2>Login</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                
            </div>
            <div class="form-group captcha-container">
                CAPTCHA: <span id="captcha"></span>
            </div>
            <div class="form-group">
                <input type="text" id="captchaInput" name="captchaInput" placeholder="Enter CAPTCHA" required>
                <div id="captchaError" class="error"><?php echo $errorMessage; ?></div> 
                <input type="text" id="validateCaptcha" name="validateCaptcha" hidden>
            </div>
            <div class="form-group">
                <button type="button" onclick="generateCaptcha()">Refresh CAPTCHA</button>
            </div>
            <div class="container">
                <button type="submit" name="submit" class="button">Login</button>
                <button type="button" onclick="redirectToRegistration()" class="button">Sign-in</button>
            </div>
            <?php if (isset($error)): ?>
                    <span class="error"><?php echo $error; ?></span>
            <?php endif; ?><br>
        </form>
    </div>
</body>
 <script>
        // Function to generate a random CAPTCHA code
        function generateCaptcha() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            let captchaCode = '';
            for (let i = 0; i < 6; i++) {
                captchaCode += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            
            // Set CAPTCHA code to the CAPTCHA div
            document.getElementById('captcha').innerText = captchaCode;

            // Set CAPTCHA code to a hidden input field
            document.getElementById('validateCaptcha').value = captchaCode;
        }
        function redirectToRegistration() {
            window.location.href = 'registration.php';
        }
        document.addEventListener("DOMContentLoaded", function() {
        var toast = document.getElementById("toast");
        if (toast) {
            // Show the toast
            toast.className = "toast show";
            
            // Hide the toast after 3 seconds
            setTimeout(function() {
                toast.className = toast.className.replace("show", "");
            }, 3000); // 3000 milliseconds = 3 seconds
        }
});

        // Generate CAPTCHA on page load
        window.onload = generateCaptcha;
    </script>
</html>


