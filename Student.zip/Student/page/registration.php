<?php
include '../DB connection/DB_connection.php'; 

$errorMessage = '';
$name = '';
$email = '';
$courseList = '';
$semesterList = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start(); 
    $name = htmlspecialchars(trim($_POST['Name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $courseList = htmlspecialchars(trim($_POST['courseList']));
    $semesterList = htmlspecialchars(trim($_POST['semesterList']));
    $password = htmlspecialchars(trim($_POST['password']));
    $submittedCaptcha = htmlspecialchars(trim($_POST['captchaInput']));
    $storedCaptcha = htmlspecialchars(trim($_POST['validateCaptcha']));

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    if ($submittedCaptcha !== $storedCaptcha) {
        $errorMessage = 'CAPTCHA validation failed. Please try again.';       
    }
    else{
        
        $sql = "INSERT INTO student (NAME,EMAIL,COURSE_NAME,SEMESTER,PASSWORD) VALUES (?,?,?,?,?)";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("sssss", $name,$email,$courseList,$semesterList,$hashedPassword);

        if ($stmt->execute()) {
            $stmt->close();
            $conn->close();
            
            $_SESSION['message'] = "Registration successful! You can now log in.";
            header("Location: login.php");
            exit(); 
        } else {
            $stmt->close();
            $conn->close();
            
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }

}
?>
<html>
<head>  
    <title>Registration Form</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Registration</h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="Name">Name:</label>
                <input type="text" id="Name" name="Name" value="<?php echo htmlspecialchars($name); ?>" required>
            </div>
            <div class="form-group">
                <label for="Course_Name">Course Name:</label>
                <select name="courseList" class="form-dropdawn" id="courseList" value="<?php echo htmlspecialchars($courseList); ?>">
                    <option>B.Tech</option>
                    <option>M.Tech</option>
                    <option>Bsc</option>
                    <option>Msc</option>
                    <option>BCA</option>
                    <option>MCA</option>
                </select>
            </div>
            <div class="form-group">
                <label for="Semester">Semester:</label>
                <select name="semesterList" class="form-dropdawn" id="semesterList" value="<?php echo htmlspecialchars($semesterList); ?>">
                    <option>I</option>
                    <option>II</option>
                    <option>III</option>
                    <option>IV</option>
                    <option>V</option>
                    <option>VI</option>
                    <option>VII</option>
                    <option>VIII</option>
                    <option>IX</option>
                </select>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="captcha-container">
                CAPTCHA: <span id="captcha"></span>
            </div>
            <div class="form-group">
                <input type="text" id="captchaInput" name="captchaInput" placeholder="Enter CAPTCHA" required>
                <div id="captchaError" class="error"><?php echo $errorMessage; ?></div> <!-- Display error message -->
                <input type="text" id="validateCaptcha" name="validateCaptcha" hidden>
            </div>
            <div class="form-group">
                <button type="button" onclick="generateCaptcha()">Refresh CAPTCHA</button>
            </div>
            <div class="form-group">
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
    </div>
</body>
<script>
        // Function to generate a random CAPTCHA code
        function generateCaptcha() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            let captchaCode = '';
            for (let i = 0; i < 6; i++) {
                captchaCode += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            
            // Set CAPTCHA code to the CAPTCHA div
            document.getElementById('captcha').innerText = captchaCode;

        
            document.getElementById('validateCaptcha').value = captchaCode;
        }

    
        window.onload = generateCaptcha;
    </script>
</html>
